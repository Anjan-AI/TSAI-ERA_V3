// This file is intentionally left empty as the functionality is handled by the background script.
